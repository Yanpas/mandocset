static char version[] = "1.6g";
